package com.test;

import java.io.IOException;
import java.util.Iterator;

import com.uc4.api.FolderListItem;
import com.uc4.api.Task;
import com.uc4.api.TaskFilter;
import com.uc4.api.UC4ObjectName;
import com.uc4.api.objects.IFolder;
import com.uc4.api.objects.JobPlan;
import com.uc4.api.objects.UC4Object;
import com.uc4.communication.Connection;
import com.uc4.communication.TimeoutException;
import com.uc4.communication.requests.ActivityList;
import com.uc4.communication.requests.CancelTask;
import com.uc4.communication.requests.CreateSession;
import com.uc4.communication.requests.FolderList;
import com.uc4.communication.requests.FolderTree;
import com.uc4.communication.requests.OpenObject;
import com.uc4.communication.requests.SaveObject;
import com.uc4.communication.requests.XMLRequest;

public class GoTest {

	public static void main(String[] args) throws IOException{
		
		String HOST = "192.168.1.60";
		int PORT = 2217;
		int CLIENT = 200;
		String LOGIN = "BSP";
		String DEPT = "AUTOMIC";
		String PWD = "Un1ver$e";
		char LANG = 'E';
		
		// 1- Authentication
		Connection conn = HandleConnectionToAE(HOST,PORT,CLIENT,LOGIN,DEPT,PWD,LANG);
		
		// 2- Request Definition
		// What if i want to open an actual object such as DEM.JOBP.DEMO.7?
		UC4ObjectName ObjName = new UC4ObjectName("DEM.JOBP.DEMO.7");

		OpenObject XMLReqOpen = new OpenObject(ObjName);
		
		// 3- Response Processing
		boolean ResponseOpen = SendRequestToAE(conn, XMLReqOpen);
		
		if(ResponseOpen){
			
			// Allows us to retrieve the UC$Object object
			UC4Object obj = XMLReqOpen.getUC4Object();
			
			// Casting allows us to extract the actual JobPlan object...
			JobPlan jp = (JobPlan) obj;
			
			System.out.println(jp.getName() +" : " + jp.getType());
			
			
			// From which we can modify and read attributes!
			jp.header().setArchiveKey1("");
			
			System.out.println("New Archive Key 1 is:" +jp.header().getArchiveKey1());
			
			SaveObject XMLReqSave = new SaveObject(obj);
			boolean ResponseSave = SendRequestToAE(conn, XMLReqSave);
			
			if(ResponseSave){
				
				
			}
		}
	
	}
	
	public static boolean SendRequestToAE(Connection conn, XMLRequest req) throws TimeoutException, IOException{
		
		conn.sendRequestAndWait(req);

		if(req.getMessageBox() != null){
			System.out.println("Error: " + req.getMessageBox());
			return false;
		}else{
			return true;
		}
	}
	
	
	public static Connection HandleConnectionToAE(String HOST, int PORT, int CLIENT, String LOGIN, String DEPT, String PWD, char LANG) throws IOException{
		
		// authentication - part 1: declare AE server
		Connection myAEConnection = Connection.open(HOST, PORT);
		// authentication - part 2: give credentials
		CreateSession mySession = myAEConnection.login(CLIENT,LOGIN, DEPT, PWD, LANG);
		
		if(mySession.getMessageBox() != null){
			// there is a message hence there is an error
			System.out.println("--Error: " + mySession.getMessageBox());
			return null;
		}else{
			// connection successful
			System.out.println("+ OK!: Connection Successful!");
			return myAEConnection;
		}
		
	}
	
}
